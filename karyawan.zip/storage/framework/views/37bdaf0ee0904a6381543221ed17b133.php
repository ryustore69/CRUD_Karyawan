<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Produk | E-Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('product.index')); ?>">Daftar Produk</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?php echo e(route('product.index')); ?>">Produk</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="py-4 flex-grow-1">
        <div class="container">

            <div class="d-flex align-items-center justify-content-between mb-3">
                <div>
                    <h1 class="h3 mb-0">Daftar Produk</h1>
                    <small class="text-muted">Ini adalah halaman daftar produk.</small>
                </div>
                <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary">Tambah Produk Baru</a>
            </div>

            <div class="card shadow-sm">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Detail</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->nama); ?></td>
                                <td><?php echo e($product->detail); ?></td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('product.show', $product->id)); ?>" class="btn btn-sm btn-outline-info">Lihat</a>
                                    <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                    <a href="<?php echo e(route('product.delete', $product->id)); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus produk ini?');">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <footer class="py-4 bg-light border-top mt-auto">
        <div class="container text-center text-muted">
            <small>&copy; <?php echo e(date('Y')); ?> E-Product</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Toast Container -->
    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="successToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-success text-white">
                <strong class="me-auto">Berhasil</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Tutup"></button>
            </div>
            <div class="toast-body" id="toastMessage">
                <!-- Pesan akan ditampilkan di sini -->
            </div>
        </div>
    </div>

    <script>
        // Tampilkan toast jika ada pesan sukses
        <?php if(session('success')): ?>
            document.addEventListener('DOMContentLoaded', function() {
                const toastMessage = document.getElementById('toastMessage');
                const successToast = document.getElementById('successToast');
                
                toastMessage.textContent = '<?php echo e(session('success')); ?>';
                
                const toast = new bootstrap.Toast(successToast, {
                    autohide: true,
                    delay: 3000
                });
                toast.show();
            });
        <?php endif; ?>
    </script>
</body>
</html><?php /**PATH D:\Aplikasi\laragon\www\e-productv1\resources\views/product/index.blade.php ENDPATH**/ ?>