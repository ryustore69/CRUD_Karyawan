<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Karyawan | Sistem Karyawan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('karyawans.index')); ?>">Sistem Karyawan</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?php echo e(route('karyawans.index')); ?>">Karyawan</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="py-4 flex-grow-1">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="d-flex align-items-center mb-3">
                        <a href="<?php echo e(route('karyawans.index')); ?>" class="btn btn-outline-secondary me-3">
                            <i class="bi bi-arrow-left"></i> Kembali
                        </a>
                        <div>
                            <h1 class="h3 mb-0">Tambah Karyawan Baru</h1>
                            <small class="text-muted">Isi form di bawah untuk menambah karyawan baru</small>
                        </div>
                    </div>

                    <div class="card shadow-sm">
                        <div class="card-body">
                            <!-- Display Validation Errors -->
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <strong>Terjadi kesalahan!</strong>
                                    <ul class="mb-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('karyawans.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <div class="mb-3">
                                    <label for="nama" class="form-label">Nama Karyawan <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="nama" name="nama" value="<?php echo e(old('nama')); ?>" 
                                           placeholder="Masukkan nama lengkap karyawan" required autofocus>
                                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <small class="form-text text-muted">Contoh: John Doe, Jane Smith</small>
                                </div>

                                <div class="mb-3">
                                    <label for="pendidikan" class="form-label">Pendidikan Terakhir <span class="text-danger">*</span></label>
                                    <select class="form-select <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="pendidikan" name="pendidikan" required>
                                        <option value="" disabled selected>-- Pilih Pendidikan --</option>
                                        <option value="S1" <?php echo e(old('pendidikan') == 'S1' ? 'selected' : ''); ?>>S1 (Sarjana)</option>
                                        <option value="S2" <?php echo e(old('pendidikan') == 'S2' ? 'selected' : ''); ?>>S2 (Magister)</option>
                                        <option value="S3" <?php echo e(old('pendidikan') == 'S3' ? 'selected' : ''); ?>>S3 (Doktor)</option>
                                    </select>
                                    <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-4">
                                    <label for="divisi" class="form-label">Divisi <span class="text-danger">*</span></label>
                                    <select class="form-select <?php $__errorArgs = ['divisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="divisi" name="divisi" required>
                                        <option value="" disabled selected>-- Pilih Divisi --</option>
                                        <option value="Marketing" <?php echo e(old('divisi') == 'Marketing' ? 'selected' : ''); ?>>Marketing</option>
                                        <option value="Produksi" <?php echo e(old('divisi') == 'Produksi' ? 'selected' : ''); ?>>Produksi</option>
                                        <option value="SDM" <?php echo e(old('divisi') == 'SDM' ? 'selected' : ''); ?>>SDM</option>
                                        <option value="IT" <?php echo e(old('divisi') == 'IT' ? 'selected' : ''); ?>>IT (Information Technology)</option>
                                        <option value="HRD" <?php echo e(old('divisi') == 'HRD' ? 'selected' : ''); ?>>HRD (Human Resources Development)</option>
                                        <option value="Finance" <?php echo e(old('divisi') == 'Finance' ? 'selected' : ''); ?>>Finance</option>
                                        <option value="Operations" <?php echo e(old('divisi') == 'Operations' ? 'selected' : ''); ?>>Operations</option>
                                        <option value="Quality Control" <?php echo e(old('divisi') == 'Quality Control' ? 'selected' : ''); ?>>Quality Control</option>
                                        <option value="Research & Development" <?php echo e(old('divisi') == 'Research & Development' ? 'selected' : ''); ?>>Research & Development</option>
                                        <option value="Legal" <?php echo e(old('divisi') == 'Legal' ? 'selected' : ''); ?>>Legal</option>
                                        <option value="Procurement" <?php echo e(old('divisi') == 'Procurement' ? 'selected' : ''); ?>>Procurement</option>
                                        <option value="Customer Service" <?php echo e(old('divisi') == 'Customer Service' ? 'selected' : ''); ?>>Customer Service</option>
                                    </select>
                                    <?php $__errorArgs = ['divisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="d-flex justify-content-between">
                                    <a href="<?php echo e(route('karyawans.index')); ?>" class="btn btn-secondary">
                                        <i class="bi bi-x-circle"></i> Batal
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-check-circle"></i> Simpan Karyawan
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Info Card -->
                    <div class="card mt-3 bg-light">
                        <div class="card-body">
                            <h6 class="card-title">Informasi</h6>
                            <ul class="mb-0 small">
                                <li>Semua field yang bertanda <span class="text-danger">*</span> wajib diisi</li>
                                <li>Pastikan data yang dimasukkan sudah benar sebelum menyimpan</li>
                                <li>Data karyawan dapat diubah kapan saja melalui menu edit</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="py-4 bg-light border-top mt-auto">
        <div class="container text-center text-muted">
            <small>&copy; <?php echo e(date('Y')); ?> Sistem Karyawan</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php /**PATH D:\Aplikasi\laragon\www\karyawan\resources\views/karyawans/create.blade.php ENDPATH**/ ?>