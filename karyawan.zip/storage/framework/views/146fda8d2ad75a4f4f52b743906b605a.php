<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Product - Sistem Manajemen Produk</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
    <!-- Navigasi -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?php echo e(url('/')); ?>">
                <i class="fas fa-box me-2"></i>E-Product
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(url('/')); ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('product.index')); ?>">Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-primary btn-sm ms-2" href="<?php echo e(route('product.create')); ?>">
                            <i class="fas fa-plus me-1"></i>Tambah Produk
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section py-5 flex-grow-1">
        <div class="container">
            <div class="row align-items-center min-vh-75">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold text-dark mb-4">
                        Kelola Produk Anda
                        <span class="text-primary">Dengan Efisien</span>
                    </h1>
                    <p class="lead text-muted mb-4">
                        Sebuah sistem manajemen produk yang sederhana dan kuat, dibangun dengan Laravel.
                        Buat, edit, dan atur produk Anda dengan mudah.
                    </p>
                    <div class="d-flex gap-3">
                        <a href="<?php echo e(route('product.index')); ?>" class="btn btn-primary btn-lg">
                            <i class="fas fa-list me-2"></i>Lihat Produk
                        </a>
                        <a href="<?php echo e(route('product.create')); ?>" class="btn btn-outline-primary btn-lg">
                            <i class="fas fa-plus me-2"></i>Tambah Produk Baru
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <div class="hero-image">
                        <i class="fas fa-boxes display-1 text-primary opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Fitur Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row text-center mb-5">
                <div class="col-12">
                    <h2 class="h2 fw-bold text-dark mb-3">Kenapa Memilih E-Product?</h2>
                    <p class="text-muted">Sederhana, cepat, dan dapat diandalkan</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-plus-circle fa-3x text-primary"></i>
                            </div>
                            <h5 class="card-title fw-bold">Tambah dengan Mudah</h5>
                            <p class="card-text text-muted">
                                Menambahkan produk baru sangat mudah lewat formulir sederhana.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-edit fa-3x text-success"></i>
                            </div>
                            <h5 class="card-title fw-bold">Edit Cepat</h5>
                            <p class="card-text text-muted">
                                Perbarui informasi produk langsung dengan antarmuka edit yang intuitif.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-trash fa-3x text-danger"></i>
                            </div>
                            <h5 class="card-title fw-bold">Hapus Aman</h5>
                            <p class="card-text text-muted">
                                Hapus produk dengan aman menggunakan konfirmasi agar tidak terjadi kesalahan.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistik Section -->
    <section class="py-5">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-3 mb-4">
                    <div class="stat-item">
                        <h3 class="display-6 fw-bold text-primary">100%</h3>
                        <p class="text-muted mb-0">Gratis Digunakan</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-item">
                        <h3 class="display-6 fw-bold text-success">Cepat</h3>
                        <p class="text-muted mb-0">Performa</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-item">
                        <h3 class="display-6 fw-bold text-info">Sederhana</h3>
                        <p class="text-muted mb-0">Antarmuka</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-item">
                        <h3 class="display-6 fw-bold text-warning">Aman</h3>
                        <p class="text-muted mb-0">Perlindungan Data</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5 bg-primary text-white">
        <div class="container text-center">
            <h2 class="h2 fw-bold mb-3">Siap Memulai?</h2>
            <p class="lead mb-4">Mulai kelola produk-produk Anda hari ini dengan sistem yang sederhana dan efisien.</p>
            <a href="<?php echo e(route('product.create')); ?>" class="btn btn-light btn-lg">
                <i class="fas fa-rocket me-2"></i>Mulai Sekarang
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-4 bg-dark text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0">&copy; <?php echo e(date('Y')); ?> E-Product. Dibangun dengan Laravel.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <small class="text-muted">Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?> | PHP v<?php echo e(PHP_VERSION); ?></small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH D:\Aplikasi\laragon\www\e-productv1\resources\views/welcome.blade.php ENDPATH**/ ?>