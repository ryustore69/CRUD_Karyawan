<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Manajemen Karyawan - Laravel CRUD</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 70vh;
        }
        .feature-icon {
            transition: transform 0.3s ease;
        }
        .feature-icon:hover {
            transform: scale(1.1);
        }
        .stat-item {
            padding: 2rem;
            background: #f8f9fa;
            border-radius: 10px;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <!-- Navigasi -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?php echo e(url('/')); ?>">
                <i class="fas fa-users me-2"></i>Sistem Karyawan
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(url('/')); ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('karyawans.index')); ?>">Karyawan</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-primary btn-sm ms-2" href="<?php echo e(route('karyawans.create')); ?>">
                            <i class="fas fa-plus me-1"></i>Tambah Karyawan
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section py-5 flex-grow-1 d-flex align-items-center">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">
                        Kelola Data Karyawan
                        <span class="text-white">Dengan Mudah</span>
                    </h1>
                    <p class="lead mb-4">
                        Sistem manajemen karyawan yang sederhana dan powerful, dibangun dengan Laravel 12.
                        Kelola data karyawan dengan operasi CRUD (Create, Read, Update, Delete) secara efisien.
                    </p>
                    <div class="d-flex gap-3 flex-wrap">
                        <a href="<?php echo e(route('karyawans.index')); ?>" class="btn btn-light btn-lg">
                            <i class="fas fa-list me-2"></i>Lihat Daftar Karyawan
                        </a>
                        <a href="<?php echo e(route('karyawans.create')); ?>" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-user-plus me-2"></i>Tambah Karyawan Baru
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <div class="hero-image mt-4 mt-lg-0">
                        <i class="fas fa-users-cog display-1 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Fitur Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row text-center mb-5">
                <div class="col-12">
                    <h2 class="h2 fw-bold text-dark mb-3">Fitur Utama Sistem</h2>
                    <p class="text-muted">Kelola data karyawan dengan fitur-fitur lengkap</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-user-plus fa-3x text-primary"></i>
                            </div>
                            <h5 class="card-title fw-bold">Tambah Karyawan</h5>
                            <p class="card-text text-muted">
                                Tambahkan data karyawan baru dengan mudah melalui formulir yang user-friendly.
                                Data karyawan meliputi nama, pendidikan, dan divisi.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-search fa-3x text-info"></i>
                            </div>
                            <h5 class="card-title fw-bold">Pencarian & Filter</h5>
                            <p class="card-text text-muted">
                                Cari karyawan berdasarkan nama, filter berdasarkan divisi dan pendidikan.
                                Sistem pencarian yang cepat dan akurat.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-edit fa-3x text-success"></i>
                            </div>
                            <h5 class="card-title fw-bold">Update Data</h5>
                            <p class="card-text text-muted">
                                Perbarui informasi karyawan dengan mudah. Data dapat diubah kapan saja
                                melalui formulir edit yang intuitif.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-eye fa-3x text-warning"></i>
                            </div>
                            <h5 class="card-title fw-bold">Detail Karyawan</h5>
                            <p class="card-text text-muted">
                                Lihat informasi lengkap setiap karyawan termasuk tanggal pembuatan
                                dan pembaruan terakhir data.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-sort fa-3x text-secondary"></i>
                            </div>
                            <h5 class="card-title fw-bold">Sorting Data</h5>
                            <p class="card-text text-muted">
                                Urutkan data karyawan berdasarkan ID, pendidikan, divisi, atau tanggal.
                                Sort ascending atau descending sesuai kebutuhan.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-trash-alt fa-3x text-danger"></i>
                            </div>
                            <h5 class="card-title fw-bold">Hapus Data</h5>
                            <p class="card-text text-muted">
                                Hapus data karyawan dengan konfirmasi untuk mencegah kesalahan.
                                Sistem keamanan yang terjamin.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Informasi Section -->
    <section class="py-5">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-3 mb-4">
                    <div class="stat-item">
                        <h3 class="display-6 fw-bold text-primary">
                            <i class="fas fa-user-graduate"></i>
                        </h3>
                        <p class="text-muted mb-0">Pendidikan: S1, S2, S3</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-item">
                        <h3 class="display-6 fw-bold text-success">
                            <i class="fas fa-building"></i>
                        </h3>
                        <p class="text-muted mb-0">12 Divisi Tersedia</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-item">
                        <h3 class="display-6 fw-bold text-info">
                            <i class="fas fa-shield-alt"></i>
                        </h3>
                        <p class="text-muted mb-0">Validasi Data</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-item">
                        <h3 class="display-6 fw-bold text-warning">
                            <i class="fas fa-file-alt"></i>
                        </h3>
                        <p class="text-muted mb-0">Pagination</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5 bg-primary text-white">
        <div class="container text-center">
            <h2 class="h2 fw-bold mb-3">Siap Memulai?</h2>
            <p class="lead mb-4">Mulai kelola data karyawan Anda hari ini dengan sistem yang sederhana, cepat, dan aman.</p>
            <a href="<?php echo e(route('karyawans.create')); ?>" class="btn btn-light btn-lg me-2">
                <i class="fas fa-user-plus me-2"></i>Tambah Karyawan Pertama
            </a>
            <a href="<?php echo e(route('karyawans.index')); ?>" class="btn btn-outline-light btn-lg">
                <i class="fas fa-list me-2"></i>Lihat Daftar Karyawan
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-4 bg-dark text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0">&copy; <?php echo e(date('Y')); ?> Sistem Manajemen Karyawan. Dibangun dengan Laravel 12.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <small class="text-muted">
                        Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?> | PHP v<?php echo e(PHP_VERSION); ?>

                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\Aplikasi\laragon\www\karyawan\resources\views/welcome.blade.php ENDPATH**/ ?>