<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Karyawan | Sistem Karyawan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="min-h-screen flex flex-col bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-gray-800 text-white shadow-lg">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <a href="<?php echo e(route('karyawans.index')); ?>" class="text-xl font-bold">Sistem Karyawan</a>
                <div class="flex space-x-4">
                    <a href="<?php echo e(url('/')); ?>" class="hover:text-gray-300">Beranda</a>
                    <a href="<?php echo e(route('karyawans.index')); ?>" class="text-blue-400 font-semibold">Karyawan</a>
                </div>
            </div>
        </div>
    </nav>

    <main class="flex-grow py-8">
        <div class="container mx-auto px-4 max-w-2xl">
            <!-- Header -->
            <div class="flex items-center gap-4 mb-6">
                <a href="<?php echo e(route('karyawans.index')); ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Edit Karyawan</h1>
                    <p class="text-gray-600 text-sm">Perbarui data karyawan: <strong><?php echo e($karyawan->nama); ?></strong></p>
                </div>
            </div>

            <!-- Form Card -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <!-- Validation Errors -->
                <?php if($errors->any()): ?>
                    <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-exclamation-circle text-red-400"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-red-800">Terjadi kesalahan!</p>
                                <ul class="mt-2 text-sm text-red-700 list-disc list-inside">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('karyawans.update', $karyawan->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Nama Field -->
                    <div class="mb-6">
                        <label for="nama" class="block text-sm font-medium text-gray-700 mb-2">
                            Nama Karyawan <span class="text-red-500">*</span>
                        </label>
                        <input type="text" 
                               id="nama" 
                               name="nama" 
                               value="<?php echo e(old('nama', $karyawan->nama)); ?>" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               placeholder="Masukkan nama lengkap karyawan" 
                               required 
                               autofocus>
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="mt-1 text-sm text-gray-500">Contoh: John Doe, Jane Smith</p>
                    </div>

                    <!-- Pendidikan Field -->
                    <div class="mb-6">
                        <label for="pendidikan" class="block text-sm font-medium text-gray-700 mb-2">
                            Pendidikan Terakhir <span class="text-red-500">*</span>
                        </label>
                        <select id="pendidikan" 
                                name="pendidikan" 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                required>
                            <option value="" disabled>-- Pilih Pendidikan --</option>
                            <option value="S1" <?php echo e(old('pendidikan', $karyawan->pendidikan) == 'S1' ? 'selected' : ''); ?>>S1 (Sarjana)</option>
                            <option value="S2" <?php echo e(old('pendidikan', $karyawan->pendidikan) == 'S2' ? 'selected' : ''); ?>>S2 (Magister)</option>
                            <option value="S3" <?php echo e(old('pendidikan', $karyawan->pendidikan) == 'S3' ? 'selected' : ''); ?>>S3 (Doktor)</option>
                        </select>
                        <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Divisi Field -->
                    <div class="mb-6">
                        <label for="divisi" class="block text-sm font-medium text-gray-700 mb-2">
                            Divisi <span class="text-red-500">*</span>
                        </label>
                        <select id="divisi" 
                                name="divisi" 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['divisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                required>
                            <option value="" disabled>-- Pilih Divisi --</option>
                            <option value="Marketing" <?php echo e(old('divisi', $karyawan->divisi) == 'Marketing' ? 'selected' : ''); ?>>Marketing</option>
                            <option value="Produksi" <?php echo e(old('divisi', $karyawan->divisi) == 'Produksi' ? 'selected' : ''); ?>>Produksi</option>
                            <option value="SDM" <?php echo e(old('divisi', $karyawan->divisi) == 'SDM' ? 'selected' : ''); ?>>SDM</option>
                            <option value="IT" <?php echo e(old('divisi', $karyawan->divisi) == 'IT' ? 'selected' : ''); ?>>IT (Information Technology)</option>
                            <option value="HRD" <?php echo e(old('divisi', $karyawan->divisi) == 'HRD' ? 'selected' : ''); ?>>HRD (Human Resources Development)</option>
                            <option value="Finance" <?php echo e(old('divisi', $karyawan->divisi) == 'Finance' ? 'selected' : ''); ?>>Finance</option>
                            <option value="Operations" <?php echo e(old('divisi', $karyawan->divisi) == 'Operations' ? 'selected' : ''); ?>>Operations</option>
                            <option value="Quality Control" <?php echo e(old('divisi', $karyawan->divisi) == 'Quality Control' ? 'selected' : ''); ?>>Quality Control</option>
                            <option value="Research & Development" <?php echo e(old('divisi', $karyawan->divisi) == 'Research & Development' ? 'selected' : ''); ?>>Research & Development</option>
                            <option value="Legal" <?php echo e(old('divisi', $karyawan->divisi) == 'Legal' ? 'selected' : ''); ?>>Legal</option>
                            <option value="Procurement" <?php echo e(old('divisi', $karyawan->divisi) == 'Procurement' ? 'selected' : ''); ?>>Procurement</option>
                            <option value="Customer Service" <?php echo e(old('divisi', $karyawan->divisi) == 'Customer Service' ? 'selected' : ''); ?>>Customer Service</option>
                        </select>
                        <?php $__errorArgs = ['divisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Buttons -->
                    <div class="flex justify-between items-center pt-4 border-t border-gray-200">
                        <a href="<?php echo e(route('karyawans.index')); ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg">
                            <i class="fas fa-times"></i> Batal
                        </a>
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg">
                            <i class="fas fa-check"></i> Update Karyawan
                        </button>
                    </div>
                </form>
            </div>

            <!-- Info Card -->
            <div class="bg-gray-50 rounded-lg shadow-md p-6 mt-6">
                <h6 class="font-semibold text-gray-800 mb-3">Informasi</h6>
                <ul class="text-sm text-gray-600 space-y-1">
                    <li><strong>ID Karyawan:</strong> #<?php echo e($karyawan->id); ?></li>
                    <li><strong>Dibuat pada:</strong> <?php echo e($karyawan->created_at->format('d/m/Y H:i')); ?></li>
                    <li><strong>Terakhir diupdate:</strong> <?php echo e($karyawan->updated_at->format('d/m/Y H:i')); ?></li>
                </ul>
            </div>

            <!-- Delete Card -->
            <div class="bg-red-50 border-l-4 border-red-500 rounded-lg shadow-md p-6 mt-6">
                <h6 class="font-semibold text-red-800 mb-2">Zona Bahaya</h6>
                <p class="text-sm text-red-700 mb-4">Jika Anda yakin ingin menghapus karyawan ini, klik tombol di bawah. Tindakan ini tidak dapat dibatalkan.</p>
                <form action="<?php echo e(route('karyawans.destroy', $karyawan->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus karyawan <?php echo e($karyawan->nama); ?>? Tindakan ini tidak dapat dibatalkan!');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm">
                        <i class="fas fa-trash"></i> Hapus Karyawan
                    </button>
                </form>
            </div>
        </div>
    </main>

    <footer class="bg-gray-100 border-t border-gray-200 py-4 mt-auto">
        <div class="container mx-auto px-4 text-center text-gray-600 text-sm">
            <small>&copy; <?php echo e(date('Y')); ?> Sistem Karyawan</small>
        </div>
    </footer>
</body>
</html>
<?php /**PATH D:\Aplikasi\laragon\www\karyawan\resources\views/karyawans/edit.blade.php ENDPATH**/ ?>