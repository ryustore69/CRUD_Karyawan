<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;


class Controller extends BaseController
{
    
}
/*
 * Note: The model file should be named Product.php and the class should be named Product.
 * If your model file is named productv1.php and the class is Productv1, update the import and usage:
 */


// Then update the usage in your index method:
